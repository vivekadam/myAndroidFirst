package com.vivek.bookhub

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.widget.FrameLayout
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle

import androidx.appcompat.widget.Toolbar
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationBarView
import com.google.android.material.navigation.NavigationView

class MainActivity : AppCompatActivity() {
    lateinit var drawerlayout: DrawerLayout
    lateinit var coordinatorLayout : CoordinatorLayout
    lateinit var toolbar: Toolbar
    lateinit var frameLayout: FrameLayout
    lateinit var navigationView :NavigationView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        drawerlayout = findViewById(R.id.drawerLayout)
        coordinatorLayout = findViewById(R.id.coordinatorLayout)
        toolbar = findViewById(R.id.toolbaar)
        frameLayout = findViewById(R.id.frame)
        navigationView = findViewById(R.id.navigation)
        setUpToolBar() //toolbaar fun called here
        openDashboard()
        //*/*******************************************************************************************

        //make a toggle and place it one the action bar, this toggle is known as the action bar toggle
        val actionBarDrawerToggle = ActionBarDrawerToggle(this@MainActivity,drawerlayout,
            R.string.open_drawer,
            R.string.close_drawer)

        drawerlayout.addDrawerListener(actionBarDrawerToggle)// to add click listern to it
        actionBarDrawerToggle.syncState()// sync toggle with navigation drawer


            //drawer menu click all clicklister
        navigationView.setNavigationItemSelectedListener {
            when (it.itemId){           //here item id as the munu items which are mentioned in menu_drawer.xml
                R.id.dashboard ->{
                    supportFragmentManager.beginTransaction()       //if clicked on dashboadrd then supportfragment manager ... i think for stack of oprations   and it is started
                        .replace((R.id.frame),DashboardFragment())
                        .addToBackStack("Dashboard")//the frame we used as blanck im bg now we have to replace it with other menu and here replaced it with dashboardFragment
                        //for that we have to create the DashbordFragment in MainActivity folder  new ->fragment -> and fragment blank
                        .commit() //start or apply
                    supportActionBar?.title ="Dashboard"
                    drawerlayout.closeDrawers()  // after click drawer ger close auto
                }
                R.id.favourate -> {
                    supportFragmentManager.beginTransaction()
                        .replace((R.id.frame),FavouritesFragment())
                        .addToBackStack("Favourites")
                        .commit()
                    supportActionBar?.title ="Favourites"
                    drawerlayout.closeDrawers()

                }
                R.id.profile -> {
                    supportFragmentManager.beginTransaction()
                        .replace((R.id.frame),ProfileFragment())
                        .addToBackStack("Profile")
                        .commit()
                    supportActionBar?.title ="Profile"
                    drawerlayout.closeDrawers()

                }
                R.id.About_us -> {
                    supportFragmentManager.beginTransaction()
                        .replace((R.id.frame),AboutUsFragment())
                        .addToBackStack("About us")
                        .commit()
                    supportActionBar?.title ="About Us"
                    drawerlayout.closeDrawers()
                }

            }
            return@setNavigationItemSelectedListener true  //it cant just returm noraml true value
        }

    }

    fun setUpToolBar(){
        setSupportActionBar(toolbar) //make toolbaar as actionbaar so used this method and called in onCreate
        supportActionBar?.title ="VIVI Books" // title to toolbaar ...all the below things can be empty so used '?'
        supportActionBar?.setHomeButtonEnabled(true) //to make it clicable home button
        supportActionBar?.setDisplayHomeAsUpEnabled(true) //for hamburger button as left <-- goes sysmbol
    }
    //to add a click listern to the action bar
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId

        if(id == android.R.id.home){// here only when u click on hamburger button
            drawerlayout.openDrawer(GravityCompat.END) // to make drawer open from left side of the app  -- start as right side ,.,,,, end as left side
        }
        return super.onOptionsItemSelected(item)
    }

    fun openDashboard(){  //make a function here to call the Dashboard activity
        val fragment = DashboardFragment()  // this is DashbordFragment which is used as fragment
        val transaction = supportFragmentManager.beginTransaction() //used tansaction as beginTras of fragment useing supportfragment manager
            transaction.replace(R.id.frame,DashboardFragment()) //replaced begining fram with DashboardFragent
            transaction.commit()

            supportActionBar?.title = "Dashboard"

    }

    override fun onBackPressed() {
        val frag = supportFragmentManager.findFragmentById(R.id.frame)

        when(frag){
            !is DashboardFragment -> openDashboard()

            else -> super.onBackPressed()
        }
    }

}