package com.vivek.mynewapplication

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class LoginActivity : AppCompatActivity(){



    lateinit var et_username : EditText
    lateinit var et_pass : EditText  // before onclick this things are useless therefore it is used iin a lateinit -> means lately use later
    lateinit var btn_login : Button
    lateinit var txt_fpass : TextView
    lateinit var txt_reg : TextView
    val validMobileNumber = "9824514946"  // user id and password which is static right now only 1
    val validPassword = arrayOf("vivek", "jay","robot","dobi")
     lateinit var sharedPreferences: SharedPreferences      //make sharedpreferences here

    //auto gen things ...
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sharedPreferences = getSharedPreferences(getString(R.string.Preferences_file_name), Context.MODE_PRIVATE)   //stared tthe method with private mode and file
        //setContentView(R.layout.activity_login) //here in setcontentview we can change XML files which should be visible as actibity called

        val isLoggedIn = sharedPreferences.getBoolean("isLoggedIn",false)   //make a variable where put value of false in sharedpreferances
        setContentView(R.layout.activity_login)


        title = "Log in"        // upper title
        et_username = findViewById(R.id.et_username) //lately used var
        et_pass = findViewById(R.id.et_pass) //finds the id from XML file
        btn_login = findViewById(R.id.btn_login)
        txt_fpass = findViewById(R.id.txt_fppass)
        txt_reg = findViewById(R.id.txt_reg)

        //******************************************************************************************


        txt_reg.setOnClickListener {

            val newIntent = Intent(this@LoginActivity, RegActivity::class.java)
           startActivity(newIntent)
            Toast.makeText(this@LoginActivity, "WOWO chal raha bhaiiii",Toast.LENGTH_LONG ).show()
        }
        //********************************************************************************************

        if(isLoggedIn) { //it only gets enter if it get trye vale
            val intent = Intent(this@LoginActivity, MainActivity::class.java)
            startActivity(intent)
            finish()// intent is used to set a bridge between 2 activity
        }
        //setonlicklistern used to do action after click on the button
        btn_login.setOnClickListener{
            val mobileNumber = et_username.text.toString()
            val password = et_pass.text.toString() // made variable here so we can match new given iinput with valid match   // do not use it outside the clicklistener
            var NameOfMens = "avanhger"

            if(mobileNumber == validMobileNumber) {

                when (password) {
                    validPassword[0] -> { // condition to check id and pass
                        NameOfMens = "Vivekadam"
                        savePreferances(NameOfMens)
                        intent.putExtra("Name",NameOfMens)
                        startActivity(intent)


                    }
                    validPassword[1] -> {
                        NameOfMens = "Kohat jay"
                        savePreferances(NameOfMens)
                        intent.putExtra("Name",NameOfMens)
                        startActivity(intent)


                    }
                    validPassword[2] -> {
                        NameOfMens = "chitthi robot"
                        savePreferances(NameOfMens)
                        intent.putExtra("Name",NameOfMens)
                        startActivity(intent)


                    }
                    validPassword[3] -> {
                        NameOfMens = "jadi dobie"
                        savePreferances(NameOfMens)
                        intent.putExtra("Name", NameOfMens)
                        startActivity(intent)

                    }
                    else -> {
                        Toast.makeText(this@LoginActivity, // Toast mostly use to popup a mes regarding the thing # here invalid pass
                            "Incorrect passcode",
                            Toast.LENGTH_SHORT).show()
                    }
                }
            }else{
                Toast.makeText(this@LoginActivity,"Incorrect phone no",Toast.LENGTH_SHORT).show()
            }
        }
//*****************************************************************************************************
        fun onPause() {
            super.onPause()
            finish()
        }
    }
        fun savePreferances(title:String){
            sharedPreferences.edit().putBoolean("isLoggedIn",true).apply()
            sharedPreferences.edit().putString("Title",title).apply()

        }

}


