package com.vivek.mynewapplication

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {

    var titleName : String? = "Soul food family"
    lateinit var sharedPrefrences: SharedPreferences
    lateinit var btn_logout : Button

     override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.scroller_view)

         sharedPrefrences = getSharedPreferences(getString(R.string.Preferences_file_name), Context.MODE_PRIVATE)

         setContentView(R.layout.scroller_view)

             btn_logout = findViewById(R.id.btn_logout)
             titleName = sharedPrefrences.getString("Title","foddiee")
             title = titleName

         //********************************************************************************
            btn_logout.setOnClickListener {
                val logoutIntent = Intent(this@MainActivity,LoginActivity::class.java)
                startActivity(logoutIntent)
            }
         //**************************************************************************************
         }

    }

